import { TestBed } from '@angular/core/testing';

import { BookAuthorMapService } from './book-author-map.service';

describe('BookAuthorMapService', () => {
  let service: BookAuthorMapService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BookAuthorMapService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
