export class Book 
{
    isbn!: number;
    title!: string;
    year!: number;
    price!: number;
}
