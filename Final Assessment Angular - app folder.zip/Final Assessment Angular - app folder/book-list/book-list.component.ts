import { Component, OnInit } from '@angular/core';
import { AuthorService } from '../author.service';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  str!:string;
  books!: Book[];

  constructor(private bkSvc: BookService, private authSvc: AuthorService) { }

  ngOnInit(): void {
  }

  getBookList(){
    // this.bkSvc.getBookList();
  }
  
  // searchAuthor(){
  //   this.authSvc.getAuthorByName(this.str);
  // }

  // searchBook(){
  //   this.bkSvc.getBookByTitle(this.str);
  // }
}
