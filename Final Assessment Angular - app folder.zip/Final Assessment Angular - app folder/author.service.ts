import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Author } from './author';

@Injectable({
  providedIn: 'root'
})
export class AuthorService 
{
  private baseUrl = "http://localhost:8080/author/";

  constructor(private http: HttpClient) { }

  getAuthorList(): Observable<Author[]>{
    return this.http.get<Author[]>(`${this.baseUrl.concat("author")}`);
  }

  getAuthorById(id:number): Observable<Author>{
    return this.http.get<Author>(`${this.baseUrl.concat("author")}/${id}`);
  }

  getAuthorByName(name:string): Observable<Author[]>{
    return this.http.get<Author[]>(`${this.baseUrl.concat("authorNameLike")}/${name}`)
  }

  addAuthor(author: Author): Observable<any>{
    return this.http.post(`${this.baseUrl.concat("addAuthor")}`,author);
  }

  updateAuthor(id:number, author:Author): Observable<Object>{
    return this.http.put(`${this.baseUrl.concat("updateAuthor")}/${id}`, author)
  }
}
