import { Component, OnInit } from '@angular/core';
import { Author } from '../author';
import { AuthorService } from '../author.service';
import { Book } from '../book';
import { BookAuthorMapService } from '../book-author-map.service';
import { BookService } from '../book.service';

@Component({
  selector: 'app-book-add',
  templateUrl: './book-add.component.html',
  styleUrls: ['./book-add.component.css']
})
export class BookAddComponent implements OnInit {
  book:Book = new Book();
  author: Author = new Author();

  constructor(private bookSvc: BookService, private authorSvc: AuthorService, private map:BookAuthorMapService) { }

  private saveBook(){
    this.bookSvc.addBook(this.book).subscribe(data => {
      console.log(data)
    }, error => console.log(error));
    this.authorSvc.addAuthor(this.author).subscribe(data => {
      console.log(data)
    }, error => console.log(error));
    // this.map.addMapping().subscribe(data => {
    //   console.log(data)
    // }, error => console.log(error));
  }

  ngOnInit(): void {
  }

  onSubmit(){
    this.saveBook();
  }
}
