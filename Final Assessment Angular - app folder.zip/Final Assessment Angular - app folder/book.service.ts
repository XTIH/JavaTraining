import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class BookService 
{
  private baseUrl = "http://localhost:8080/book/";

  constructor(private http: HttpClient) { }

  getBookList(): Observable<Book[]>{
    return this.http.get<Book[]>(`${this.baseUrl.concat("book")}`);
  }

  getBookById(isbn:number): Observable<Book>{
    return this.http.get<Book>(`${this.baseUrl.concat("book")}/${isbn}`);
  }

  getBookByTitle(title:string): Observable<Book[]>{
    return this.http.get<Book[]>(`${this.baseUrl.concat("bookTitleLike")}/${title}`);
  }

  addBook(book: Book): Observable<any>{
    return this.http.post(`${this.baseUrl.concat("addBook")}`,book);
  }
  
  updateBook(isbn:number, book:Book): Observable<Object>{
    return this.http.put(`${this.baseUrl.concat("updateBook")}/${isbn}`, book)
  }
}
