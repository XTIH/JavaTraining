import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BookAuthorMap } from './book-author-map';

@Injectable({
  providedIn: 'root'
})
export class BookAuthorMapService 
{
  private baseUrl = "http://localhost:8080/map/";
  constructor(private http: HttpClient) { }

  getMapping(){
    this.http.get<BookAuthorMap[]>(`${this.baseUrl.concat("map")}`);
  }

  // addMapping(){
  //   this.http.post(`${this.baseUrl.concat("addMap")}`);
  // }
}