import { BookAuthorMap } from './book-author-map';

describe('BookAuthorMap', () => {
  it('should create an instance', () => {
    expect(new BookAuthorMap()).toBeTruthy();
  });
});
