export class BookAuthorMap {
    isbn!:number;
    id!:number;
}
